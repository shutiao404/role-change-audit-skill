CREATE TABLE IF NOT EXISTS role_change_audit (
    id INTEGER PRIMARY KEY,
    actor_id INTEGER NOT NULL,
    target_id INTEGER NOT NULL,
    old_role TEXT NOT NULL,
    new_role TEXT NOT NULL,
    changed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
