from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import tempfile
import unittest

from roles import change_role

ROOT = Path(__file__).resolve().parent


class RoleChangeTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.db_path = Path(directory.name) / "roles.sqlite"
        with closing(sqlite3.connect(self.db_path)) as db, db:
            db.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
            db.executemany(
                "INSERT INTO accounts (id, role) VALUES (?, ?)",
                [(101, "admin"), (202, "member")],
            )
        with closing(sqlite3.connect(self.db_path)) as db:
            migration = ROOT / "migrations" / "001_role_change_audit.sql"
            db.executescript(migration.read_text(encoding="utf-8"))

    def query(self, sql, parameters=()):
        with closing(sqlite3.connect(self.db_path)) as db:
            return db.execute(sql, parameters).fetchall()

    def target_role(self):
        return self.query("SELECT role FROM accounts WHERE id = ?", (202,))[0][0]

    def test_admin_can_change_role(self):
        self.assertTrue(change_role(self.db_path, 101, 202, "admin"))
        self.assertEqual(self.target_role(), "admin")

    def test_member_cannot_change_role(self):
        with self.assertRaises(PermissionError):
            change_role(self.db_path, 202, 101, "member")
        self.assertEqual(self.query("SELECT role FROM accounts WHERE id = 101"), [("admin",)])

    def test_same_role_is_a_noop(self):
        self.assertFalse(change_role(self.db_path, 101, 202, "member"))
        self.assertEqual(self.target_role(), "member")

    def audit_rows(self):
        return self.query(
            "SELECT actor_id, target_id, old_role, new_role, changed_at "
            "FROM role_change_audit ORDER BY id"
        )

    def test_success_commits_role_and_one_audit_record(self):
        earliest = datetime.now(timezone.utc).replace(microsecond=0)
        self.assertTrue(change_role(self.db_path, 101, 202, "admin"))
        latest = datetime.now(timezone.utc).replace(microsecond=0)

        self.assertEqual(self.target_role(), "admin")
        rows = self.audit_rows()
        self.assertEqual(len(rows), 1)
        actor, target, old_role, new_role, timestamp = rows[0]
        self.assertEqual((actor, target, old_role, new_role), (101, 202, "member", "admin"))
        changed_at = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc
        )
        self.assertLessEqual(earliest, changed_at)
        self.assertLessEqual(changed_at, latest)

    def test_audit_insert_error_rolls_back_role(self):
        with closing(sqlite3.connect(self.db_path)) as db, db:
            db.executescript("""
                CREATE TRIGGER reject_audit_insert
                BEFORE INSERT ON role_change_audit
                BEGIN
                    SELECT RAISE(ABORT, 'test audit insert failure');
                END;
            """)

        with self.assertRaisesRegex(sqlite3.IntegrityError, "test audit insert failure"):
            change_role(self.db_path, 101, 202, "admin")

        self.assertEqual(self.target_role(), "member")
        self.assertEqual(self.audit_rows(), [])

    def test_denied_request_leaves_no_success_record(self):
        with self.assertRaises(PermissionError):
            change_role(self.db_path, 202, 101, "member")
        self.assertEqual(self.audit_rows(), [])

    def test_noop_leaves_no_success_record(self):
        self.assertFalse(change_role(self.db_path, 101, 202, "member"))
        self.assertEqual(self.audit_rows(), [])


if __name__ == "__main__":
    unittest.main()
