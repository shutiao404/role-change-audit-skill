"""Inspect the database state after committed and rejected writes."""
from contextlib import closing
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory

root = Path.cwd()
sys.path.insert(0, str(root))
from roles import change_role


def read_state(db_path):
    with closing(sqlite3.connect(db_path)) as db:
        target_role = db.execute(
            "SELECT role FROM accounts WHERE id = 202"
        ).fetchone()[0]
        audit = db.execute(
            "SELECT actor_id, target_id, old_role, new_role, changed_at "
            "FROM role_change_audit ORDER BY id"
        ).fetchall()
        return target_role, audit


def run_case(db_path, reject_audit):
    with closing(sqlite3.connect(db_path)) as db, db:
        db.executescript((root / "schema.sql").read_text(encoding="utf-8"))
        db.executemany("INSERT INTO accounts VALUES (?, ?)", [(101, "admin"), (202, "member")])
    with closing(sqlite3.connect(db_path)) as db:
        migration = root / "migrations" / "001_role_change_audit.sql"
        db.executescript(migration.read_text(encoding="utf-8"))
        if reject_audit:
            db.executescript("""
                CREATE TRIGGER reject_audit_insert
                BEFORE INSERT ON role_change_audit
                BEGIN
                    SELECT RAISE(ABORT, 'test audit insert failure');
                END;
            """)

    print("case:", "audit write rejected" if reject_audit else "success")
    print("before:", read_state(db_path))
    try:
        changed = change_role(db_path, 101, 202, "admin")
    except sqlite3.IntegrityError as error:
        if not reject_audit:
            raise
        print("exception:", type(error).__name__, str(error))
        role, audit = read_state(db_path)
        assert (role, audit) == ("member", [])
    else:
        assert changed and not reject_audit
        role, audit = read_state(db_path)
        assert role == "admin" and len(audit) == 1
        assert audit[0][:4] == (101, 202, "member", "admin")
        print("changed:", changed)
    print("after:", (role, audit))
    print()


if __name__ == "__main__":
    with TemporaryDirectory() as folder:
        run_case(Path(folder) / "success.sqlite", reject_audit=False)
        run_case(Path(folder) / "rejected.sqlite", reject_audit=True)
