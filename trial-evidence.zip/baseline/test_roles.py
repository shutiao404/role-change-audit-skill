from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest

from roles import change_role

ROOT = Path(__file__).resolve().parent


class RoleChangeTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.db_path = Path(directory.name) / "roles.sqlite"
        with closing(sqlite3.connect(self.db_path)) as db, db:
            db.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
            db.executemany(
                "INSERT INTO accounts (id, role) VALUES (?, ?)",
                [(101, "admin"), (202, "member")],
            )

    def query(self, sql, parameters=()):
        with closing(sqlite3.connect(self.db_path)) as db:
            return db.execute(sql, parameters).fetchall()

    def target_role(self):
        return self.query("SELECT role FROM accounts WHERE id = ?", (202,))[0][0]

    def test_admin_can_change_role(self):
        self.assertTrue(change_role(self.db_path, 101, 202, "admin"))
        self.assertEqual(self.target_role(), "admin")

    def test_member_cannot_change_role(self):
        with self.assertRaises(PermissionError):
            change_role(self.db_path, 202, 101, "member")
        self.assertEqual(self.query("SELECT role FROM accounts WHERE id = 101"), [("admin",)])

    def test_same_role_is_a_noop(self):
        self.assertFalse(change_role(self.db_path, 101, 202, "member"))
        self.assertEqual(self.target_role(), "member")


if __name__ == "__main__":
    unittest.main()
