"""Role updates for the local SQLite example."""
from contextlib import closing
import sqlite3


def change_role(db_path, actor_id, target_id, new_role):
    """Change an account's role and return whether it changed."""
    if new_role not in {"member", "admin"}:
        raise ValueError("unknown role")

    with closing(sqlite3.connect(db_path)) as db, db:
        db.execute("BEGIN IMMEDIATE")
        actor = db.execute(
            "SELECT role FROM accounts WHERE id = ?", (actor_id,)
        ).fetchone()
        if actor is None or actor[0] != "admin":
            raise PermissionError("administrator role required")

        target = db.execute(
            "SELECT role FROM accounts WHERE id = ?", (target_id,)
        ).fetchone()
        if target is None:
            raise LookupError("target account not found")
        if target[0] == new_role:
            return False

        db.execute(
            "UPDATE accounts SET role = ? WHERE id = ?", (new_role, target_id)
        )
        return True
