CREATE TABLE accounts (
    id INTEGER PRIMARY KEY,
    role TEXT NOT NULL CHECK (role IN ('member', 'admin'))
);
