# 角色变更审计试用材料

- `baseline/` 是作为改造起点的自建示例，已有管理员角色变更功能。
- `demo/` 是改造后的项目，包含 Python 模块、已存在的基线建表语句、新增迁移、测试和项目级 Skill。
- `change.diff` 是三处实际代码变更。
- `evidence/` 包含会话摘录和四次运行日志。`trial_readback.py` 可重现数据库查询。

## 复跑与核对

使用 Python 3.8 及以上版本，无需第三方包。实际运行环境为 Windows、Python 3.12.14、SQLite 3.53.1。

在 `baseline/` 和 `demo/` 中各运行 `python -B -m unittest -v`，分别可复现 3 项和 7 项通过。测试先建基线账号表并写入虚构账号，再给数据库执行审计迁移。

在 `demo/` 中运行 `python -B ../trial_readback.py`。脚本会创建两个临时库，分别演示成功和审计写入失败，打印调用前后的角色和审计表。时间戳取本次运行的 UTC 时间。

要复现改动前的失败，复制 `baseline/` 到临时目录，仅将 `demo/test_roles.py` 和 `demo/migrations/` 放入该目录。保留旧版 `roles.py`。然后运行 `evidence/02-red.log` 第一行中的命令（省略开头的 `$`）。两项新增测试预期失败。

已有示例数据库在使用新版 `change_role` 前，须先执行 `demo/migrations/001_role_change_audit.sql`。测试与演示都在本地临时库执行迁移。拒绝审计写入的触发器只出现在测试和演示中。

## 复用 Skill

`demo/.agents/skills/role-change-audit/SKILL.md` 已按 Codex 的项目路径放好。若要让 Codex 从基线重做，复制 `baseline/` 到新目录并把 `demo/.agents/` 放进该副本。用 Codex 打开副本项目，从技能列表选择 `$role-change-audit`，或明确要求它读取相对路径 `.agents/skills/role-change-audit/SKILL.md` 并按规则执行。本次作业采用后一种读取方式。

可复制的任务提示语：

> 使用 $role-change-audit 给已有的 SQLite 角色变更添加审计。沿用原有管理员授权规则。仅在角色确实改变时写成功记录，字段包括操作者、目标账号、旧角色、新角色和 UTC 时间。若审计写入失败，让调用方收到错误，并回滚此次角色更新。请用临时库执行测试并保存改动前后的实际结果。
